package br.senai.sp.odonto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontoApplicationTests {

	@Test
	void contextLoads() {
	}

}
