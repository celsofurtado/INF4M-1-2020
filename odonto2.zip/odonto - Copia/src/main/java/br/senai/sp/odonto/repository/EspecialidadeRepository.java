package br.senai.sp.odonto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.senai.sp.odonto.model.Especialidade;

public interface EspecialidadeRepository extends JpaRepository<Especialidade, Long> {

}
