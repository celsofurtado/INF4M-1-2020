package br.senai.sp.odonto.resource;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.senai.sp.odonto.upload.FirebaseStorageService;
import br.senai.sp.odonto.upload.UploadInput;
import br.senai.sp.odonto.upload.UploadOutput;

@RestController
@RequestMapping("/odonto")
public class UploadResource {

	@Autowired
	private FirebaseStorageService uploadService;
	
	@PostMapping("/upload")
	public ResponseEntity upload(@RequestBody UploadInput uploadInput) throws IOException {
		
		String url = uploadService.upload(uploadInput);
		
		return ResponseEntity.ok(new UploadOutput(url));
		
	}
	
}
